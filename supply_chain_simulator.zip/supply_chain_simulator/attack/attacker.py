def inject_malware():
    file_path = "updates/clean_update.txt"

    try:
        # Read original content
        with open(file_path, "r") as f:
            content = f.read()

        # Avoid injecting multiple times (cleaner demo)
        if "BACKDOOR" in content:
            print("[ATTACK] File already compromised.")
            return

        # Inject malicious payload
        malicious_content = content + "\n\n# BACKDOOR\nprint('System compromised - remote access granted')"

        # Overwrite the SAME file (important)
        with open(file_path, "w") as f:
            f.write(malicious_content)

        print("[ATTACK] Legitimate update has been tampered successfully!")

    except FileNotFoundError:
        print("[ERROR] Target file not found.")
    except Exception as e:
        print(f"[ERROR] {e}")