from flask import Flask, render_template, redirect, url_for

from attack.attacker import inject_malware
from defense.signature import sign_file, verify_signature
from defense.integrity import verify_integrity

app = Flask(__name__)

FILE_PATH = "updates/clean_update.txt"

# 🟢 Home Dashboard
@app.route("/")
def home():
    integrity = verify_integrity(FILE_PATH)
    signature = verify_signature(FILE_PATH)

    if integrity and signature:
        status = "TRUSTED"
        color = "trusted"
    elif not integrity:
        status = "COMPROMISED"
        color = "compromised"
    else:
        status = "UNTRUSTED"
        color = "warning"

    return render_template(
        "dashboard.html",
        integrity=integrity,
        signature=signature,
        status=status,
        color=color
    )

# ✍️ Sign legit update (vendor action)
@app.route("/sign")
def sign():
    sign_file(FILE_PATH)
    return redirect(url_for("home"))

# 🔴 Simulate attack
@app.route("/attack")
def attack():
    inject_malware()
    return redirect(url_for("home"))

# 🔍 Check update manually
@app.route("/check")
def check():
    integrity = verify_integrity(FILE_PATH)
    signature = verify_signature(FILE_PATH)

    if integrity and signature:
        return "✅ TRUSTED: File is safe"
    elif not integrity:
        return "❌ COMPROMISED: Integrity failed"
    else:
        return "❌ UNTRUSTED: Signature invalid"


if __name__ == "__main__":
    app.run(debug=True)