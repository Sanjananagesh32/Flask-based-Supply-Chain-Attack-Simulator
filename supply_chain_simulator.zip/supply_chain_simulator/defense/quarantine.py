import shutil, os

def quarantine_file(file_path):
    os.makedirs("quarantine", exist_ok=True)
    new_path = "quarantine/" + file_path.split("/")[-1]
    shutil.move(file_path, new_path)

    print(f"[ACTION] Quarantined: {new_path}")