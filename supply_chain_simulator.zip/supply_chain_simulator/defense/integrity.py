import hashlib, json

def calculate_hash(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(4096):
            sha256.update(chunk)
    return sha256.hexdigest()

def store_baseline(file_path):
    hash_val = calculate_hash(file_path)
    json.dump({"file": file_path, "hash": hash_val},
              open("hashes/baseline.json", "w"))

def verify_integrity(file_path):
    data = json.load(open("hashes/baseline.json"))
    return calculate_hash(file_path) == data["hash"]