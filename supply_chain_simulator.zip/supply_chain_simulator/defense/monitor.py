from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from defense.integrity import verify_integrity
from defense.signature import verify_signature
from defense.quarantine import quarantine_file
import time

class Handler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.is_directory:
            return

        print(f"[MONITOR] {event.src_path} modified")

        integrity_ok = verify_integrity(event.src_path)
        signature_ok = verify_signature(event.src_path)

        if not integrity_ok:
            print("[ALERT] Integrity failed")

        if not signature_ok:
            print("[ALERT] Signature failed")

        if not integrity_ok or not signature_ok:
            quarantine_file(event.src_path)

def start():
    observer = Observer()
    observer.schedule(Handler(), "updates", recursive=False)
    observer.start()

    print("[DEFENSE] Monitoring started")

    try:
        while True:
            time.sleep(2)
    except KeyboardInterrupt:
        observer.stop()

    observer.join()

if __name__ == "__main__":
    start()