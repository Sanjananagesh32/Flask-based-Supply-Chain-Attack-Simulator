from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
import os


SIGNATURE_FILE = "signatures/update.sig"
PUBLIC_KEY_FILE = "keys/public.pem"
PRIVATE_KEY_FILE = "keys/private.pem"


# ✍️ SIGN FILE (Vendor Action)
def sign_file(file_path):
    try:
        # Read file data
        with open(file_path, "rb") as f:
            data = f.read()

        # Load private key
        private_key = RSA.import_key(open(PRIVATE_KEY_FILE).read())

        # Create hash of file
        h = SHA256.new(data)

        # Generate signature
        signature = pkcs1_15.new(private_key).sign(h)

        # Save signature
        with open(SIGNATURE_FILE, "wb") as f:
            f.write(signature)

        print("[SIGN] File signed successfully.")

    except Exception as e:
        print(f"[SIGN ERROR] {e}")


# ✔️ VERIFY SIGNATURE
def verify_signature(file_path):
    try:
        # Check if signature exists
        if not os.path.exists(SIGNATURE_FILE):
            print("[VERIFY] No signature found.")
            return False

        # Read CURRENT file content (important!)
        with open(file_path, "rb") as f:
            data = f.read()

        # Load public key
        public_key = RSA.import_key(open(PUBLIC_KEY_FILE).read())

        # Load stored signature
        with open(SIGNATURE_FILE, "rb") as f:
            signature = f.read()

        # Hash CURRENT file
        h = SHA256.new(data)

        # Verify signature
        pkcs1_15.new(public_key).verify(h, signature)

        print("[VERIFY] Signature is VALID.")
        return True

    except (ValueError, TypeError):
        print("[VERIFY] Signature is INVALID!")
        return False

    except Exception as e:
        print(f"[VERIFY ERROR] {e}")
        return False